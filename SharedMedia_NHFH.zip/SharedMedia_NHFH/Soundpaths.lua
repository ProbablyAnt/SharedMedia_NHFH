local LSM = LibStub("LibSharedMedia-3.0") 

LSM:Register("sound", "|cFFFF69B4NecComeToPoppa|r", [[Interface\Addons\SharedMedia_NHFH\sound\NecComeToPoppa.ogg]])
LSM:Register("sound", "|cFFFF69B4NecOhNo|r", [[Interface\Addons\SharedMedia_NHFH\sound\NecOhNo.ogg]])
LSM:Register("sound", "|cFFFF69B4NecStupidCunt|r", [[Interface\Addons\SharedMedia_NHFH\sound\NecStupidCunt.ogg]])
